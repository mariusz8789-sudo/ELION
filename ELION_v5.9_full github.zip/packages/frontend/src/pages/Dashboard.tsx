import { useTranslation } from 'react-i18next';

export default function Dashboard() {
  const { t } = useTranslation();

  return (
    <div>
      <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-elion-gold to-elion-amber bg-clip-text text-transparent">
        {t('welcome')}
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-black/30 border border-elion-gold/20 rounded-lg p-6">
          <h3 className="text-xl font-semibold text-elion-gold mb-2">Active Projects</h3>
          <p className="text-4xl font-bold">12</p>
        </div>
        
        <div className="bg-black/30 border border-elion-gold/20 rounded-lg p-6">
          <h3 className="text-xl font-semibold text-elion-gold mb-2">Completion Rate</h3>
          <p className="text-4xl font-bold">87%</p>
        </div>
        
        <div className="bg-black/30 border border-elion-gold/20 rounded-lg p-6">
          <h3 className="text-xl font-semibold text-elion-gold mb-2">Total Services</h3>
          <p className="text-4xl font-bold">5</p>
        </div>
      </div>
    </div>
  );
}

