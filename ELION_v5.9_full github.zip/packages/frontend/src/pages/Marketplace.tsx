export default function Marketplace() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-elion-gold">Marketplace</h1>
      <p className="text-gray-300">Marketplace page - Coming soon</p>
    </div>
  );
}
