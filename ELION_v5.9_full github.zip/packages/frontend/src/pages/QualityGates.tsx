export default function QualityGates() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-elion-gold">QualityGates</h1>
      <p className="text-gray-300">QualityGates page - Coming soon</p>
    </div>
  );
}
