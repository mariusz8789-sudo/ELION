export default function SpaceOps() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-elion-gold">SpaceOps</h1>
      <p className="text-gray-300">SpaceOps page - Coming soon</p>
    </div>
  );
}
