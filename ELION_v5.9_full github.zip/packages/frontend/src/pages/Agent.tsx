export default function Agent() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4 text-elion-gold">Agent</h1>
      <p className="text-gray-300">Agent page - Coming soon</p>
    </div>
  );
}
