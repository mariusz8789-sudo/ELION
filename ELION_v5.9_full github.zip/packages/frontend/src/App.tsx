import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Dashboard from './pages/Dashboard';
import Agent from './pages/Agent';
import Marketplace from './pages/Marketplace';
import Governance from './pages/Governance';
import QualityGates from './pages/QualityGates';
import SpaceOps from './pages/SpaceOps';

function App() {
  const { t, i18n } = useTranslation();

  const changeLang = (lang: string) => {
    i18n.changeLanguage(lang);
  };

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-elion-dark text-white">
        {/* Navbar */}
        <nav className="bg-black/50 border-b border-elion-gold/20 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src="/brand/elion-logo.png" alt="ELION" className="h-10 w-10" />
              <span className="text-2xl font-bold bg-gradient-to-r from-elion-gold to-elion-amber bg-clip-text text-transparent">
                ELION
              </span>
            </div>
            
            <div className="flex items-center gap-6">
              <Link to="/" className="hover:text-elion-gold transition">{t('dashboard')}</Link>
              <Link to="/agent" className="hover:text-elion-gold transition">{t('agent')}</Link>
              <Link to="/marketplace" className="hover:text-elion-gold transition">{t('marketplace')}</Link>
              <Link to="/governance" className="hover:text-elion-gold transition">{t('governance')}</Link>
              <Link to="/quality" className="hover:text-elion-gold transition">{t('quality')}</Link>
              <Link to="/spaceops" className="hover:text-elion-gold transition">{t('spaceops')}</Link>
              
              <div className="flex gap-2 ml-4 border-l border-elion-gold/20 pl-4">
                <button onClick={() => changeLang('en')} className="px-2 py-1 rounded hover:bg-elion-gold/20 transition">EN</button>
                <button onClick={() => changeLang('pl')} className="px-2 py-1 rounded hover:bg-elion-gold/20 transition">PL</button>
                <button onClick={() => changeLang('ar')} className="px-2 py-1 rounded hover:bg-elion-gold/20 transition">AR</button>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/agent" element={<Agent />} />
            <Route path="/marketplace" element={<Marketplace />} />
            <Route path="/governance" element={<Governance />} />
            <Route path="/quality" element={<QualityGates />} />
            <Route path="/spaceops" element={<SpaceOps />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;

