import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      welcome: 'Welcome to ELION',
      dashboard: 'Dashboard',
      agent: 'Agent',
      marketplace: 'Marketplace',
      governance: 'Governance',
      quality: 'Quality Gates',
      spaceops: 'SpaceOps',
    },
  },
  pl: {
    translation: {
      welcome: 'Witamy w ELION',
      dashboard: 'Panel',
      agent: 'Agent',
      marketplace: 'Rynek',
      governance: 'Zarządzanie',
      quality: 'Bramy Jakości',
      spaceops: 'SpaceOps',
    },
  },
  ar: {
    translation: {
      welcome: 'مرحبا بك في ELION',
      dashboard: 'لوحة القيادة',
      agent: 'وكيل',
      marketplace: 'السوق',
      governance: 'الحوكمة',
      quality: 'بوابات الجودة',
      spaceops: 'SpaceOps',
    },
  },
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;

