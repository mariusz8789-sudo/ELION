import { Worker, Queue } from 'bullmq';
import Redis from 'ioredis';

const connection = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  maxRetriesPerRequest: null,
});

const queue = new Queue('elion-jobs', { connection });

const worker = new Worker(
  'elion-jobs',
  async (job) => {
    console.log(`Processing job ${job.id}:`, job.data);
    
    // Simulate processing
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return { status: 'completed', result: 'Success' };
  },
  {
    connection,
    concurrency: parseInt(process.env.WORKER_CONCURRENCY || '3'),
  }
);

worker.on('completed', (job) => {
  console.log(`✅ Job ${job.id} completed`);
});

worker.on('failed', (job, err) => {
  console.error(`❌ Job ${job?.id} failed:`, err.message);
});

console.log('✅ Worker started');

