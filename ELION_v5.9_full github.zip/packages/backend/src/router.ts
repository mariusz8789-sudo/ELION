import { initTRPC } from '@trpc/server';
import { z } from 'zod';

const t = initTRPC.create();

export const appRouter = t.router({
  health: t.procedure.query(() => {
    return { status: 'ok', timestamp: new Date().toISOString() };
  }),
  
  createJob: t.procedure
    .input(z.object({ prompt: z.string(), image: z.string().optional() }))
    .mutation(async ({ input }) => {
      // Create job logic
      return { jobId: `job_${Date.now()}`, status: 'pending' };
    }),
  
  getJobs: t.procedure.query(async () => {
    // Get jobs logic
    return [];
  }),
});

export type AppRouter = typeof appRouter;

