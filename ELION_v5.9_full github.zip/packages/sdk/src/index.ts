import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';

export function createElionClient(config: { url: string; token?: string }) {
  return createTRPCProxyClient<any>({
    links: [
      httpBatchLink({
        url: `${config.url}/api/trpc`,
        headers: config.token ? { Authorization: `Bearer ${config.token}` } : {},
      }),
    ],
  });
}

