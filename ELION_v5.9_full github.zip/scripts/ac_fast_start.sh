#!/usr/bin/env bash
set -euo pipefail

echo "🚀 ELION v5.9 Fast-Track Deployment"
echo "===================================="

# Check Docker
command -v docker >/dev/null || { echo "❌ Docker not found"; exit 1; }
echo "✅ Docker OK"

# Generate .env if missing
if [ ! -f .env ]; then
  cp .env.example .env
  JWT_SECRET=$(openssl rand -hex 32)
  if [[ "$OSTYPE" == "darwin"* ]]; then
    sed -i '' "s|^JWT_SECRET=.*$|JWT_SECRET=${JWT_SECRET}|" .env
  else
    sed -i "s|^JWT_SECRET=.*$|JWT_SECRET=${JWT_SECRET}|" .env
  fi
  echo "✅ .env created with JWT_SECRET"
else
  echo "⚠ .env exists"
fi

# Start services
echo "▶ Starting services..."
docker compose -f docker-compose.prod.yml up -d --build

# Wait
echo "⏳ Waiting 15s for services..."
sleep 15

# Health checks
echo "▶ Health checks:"
echo -n "Backend: "
curl -sf http://localhost:3001/api/health >/dev/null && echo "✅ PASS" || echo "❌ FAIL"

echo -n "Frontend: "
curl -sf http://localhost:3000 >/dev/null && echo "✅ PASS" || echo "❌ FAIL"

echo -n "Redis: "
docker exec elion-redis redis-cli ping | grep -q PONG && echo "✅ PASS" || echo "❌ FAIL"

echo -n "PostgreSQL: "
docker exec elion-postgres pg_isready -U elion_user >/dev/null && echo "✅ PASS" || echo "❌ FAIL"

echo ""
echo "🎯 Deployment complete!"
echo "Frontend: http://localhost:3000"
echo "Backend: http://localhost:3001"

